package ui.exception;

public class LogException extends Exception {
}
