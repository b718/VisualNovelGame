package ui;

public class Main {
    public static void main(String[] args) {
        //new AdventureApp();
        new UI();
        // THIS STARTS OUR GAME!
    }
}
